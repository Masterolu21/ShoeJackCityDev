export { default } from './Footer.container';
