export { default } from './InputText.component';
