// Initialize Firebase
  export const firebaseConfig = {
    apiKey: 'AIzaSyAC6YlWV-KmLlnorSkTFSh0I0mo7ZRMIJY',
    authDomain: 'shoejackcity-729f9.firebaseapp.com',
    databaseURL: 'https://shoejackcity-729f9.firebaseio.com',
    projectId: 'shoejackcity-729f9',
    storageBucket: 'shoejackcity-729f9.appspot.com',
    messagingSenderId: '863761628819'
  };
